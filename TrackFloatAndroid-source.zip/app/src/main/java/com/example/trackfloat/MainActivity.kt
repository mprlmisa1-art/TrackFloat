package com.example.trackfloat

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var trackText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF17131F.toInt())
        }
        fun text(value: String, size: Float = 16f) = TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 10, 0, 10)
        }
        fun button(label: String, action: () -> Unit) = Button(this).apply {
            this.text = label
            setOnClickListener { action() }
        }

        layout.addView(text("TrackFloat", 28f))
        layout.addView(text("Плавающая кнопка и определение трека по уведомлению YouTube Music."))
        trackText = text("Текущий трек: пока не обнаружен")
        layout.addView(trackText)
        layout.addView(button("Обновить информацию о треке") { refreshTrack() })
        layout.addView(button("Разрешить доступ к уведомлениям") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })
        layout.addView(button("Разрешить отображение поверх окон") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else toast("Разрешение уже выдано")
        })
        layout.addView(button("Запустить плавающую кнопку") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                toast("Сначала разреши отображение поверх окон, затем нажми ещё раз")
            } else {
                startService(Intent(this, FloatingButtonService::class.java))
                toast("Плавающая кнопка запущена")
            }
        })
        layout.addView(button("Открыть поиск трека в YouTube Music") {
            val title = getSharedPreferences("track", MODE_PRIVATE).getString("title", "") ?: ""
            val artist = getSharedPreferences("track", MODE_PRIVATE).getString("artist", "") ?: ""
            val query = Uri.encode(listOf(title, artist).filter { it.isNotBlank() }.joinToString(" "))
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=$query")))
        })
        layout.addView(text("Загрузка разрешённых аудиофайлов по прямой ссылке HTTP(S):"))
        val urlInput = EditText(this).apply {
            hint = "https://example.com/audio.mp3"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB8AFC4.toInt())
        }
        layout.addView(urlInput)
        layout.addView(button("Скачать по ссылке") { download(urlInput.text.toString().trim()) })
        layout.addView(text("Важно: приложение не извлекает защищённый аудиопоток YouTube Music и не обходит DRM. Сохраняй только файлы, которые разрешено скачивать." , 12f))
        setContentView(layout)
        refreshTrack()
    }

    override fun onResume() {
        super.onResume()
        refreshTrack()
    }

    private fun refreshTrack() {
        val prefs = getSharedPreferences("track", MODE_PRIVATE)
        val title = prefs.getString("title", null)
        val artist = prefs.getString("artist", null)
        trackText.text = if (title.isNullOrBlank()) "Текущий трек: пока не обнаружен. Включи музыку и разреши доступ к уведомлениям." else "Сейчас играет: $title\nИсполнитель: ${artist ?: "неизвестен"}"
    }

    private fun download(url: String) {
        val uri = runCatching { Uri.parse(url) }.getOrNull()
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            toast("Введи корректную прямую HTTP(S)-ссылку на файл")
            return
        }
        runCatching {
            val request = DownloadManager.Request(uri)
                .setTitle("TrackFloat audio")
                .setDescription("Загрузка аудиофайла")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "TrackFloat-${System.currentTimeMillis()}.mp3")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            toast("Загрузка добавлена")
        }.onFailure { toast("Не удалось начать загрузку: ${it.message}") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}

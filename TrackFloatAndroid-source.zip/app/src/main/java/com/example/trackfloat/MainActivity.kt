package com.example.trackfloat

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var trackLabel: TextView
    private lateinit var urlInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("track", Context.MODE_PRIVATE)
        val title = prefs.getString("title", "Трек не определён") ?: "Трек не определён"
        val artist = prefs.getString("artist", "") ?: ""

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        trackLabel = TextView(this).apply {
            textSize = 20f
            text = "Сейчас играет:\n$title\n$artist"
        }
        urlInput = EditText(this).apply {
            hint = "Прямая ссылка на разрешённый аудиофайл"
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(true)
        }
        val download = Button(this).apply {
            text = "Скачать аудиофайл"
            setOnClickListener { downloadAuthorizedFile() }
        }
        val search = Button(this).apply {
            text = "Найти этот трек"
            setOnClickListener {
                val query = Uri.encode("$title $artist")
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://music.youtube.com/search?q=$query")))
            }
        }
        val overlay = Button(this).apply {
            text = "Разрешить плавающую кнопку"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val mediaAccess = Button(this).apply {
            text = "Разрешить доступ к медиаплееру"
            setOnClickListener {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }
        val start = Button(this).apply {
            text = "Включить плавающую кнопку"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingButtonService::class.java))
                    Toast.makeText(this@MainActivity, "Кнопка включена", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@MainActivity, "Сначала разреши отображение поверх окон", Toast.LENGTH_LONG).show()
                }
            }
        }

        layout.addView(trackLabel)
        layout.addView(search)
        layout.addView(TextView(this).apply {
            text = "Загрузка доступна для прямых ссылок на файлы, которые ты вправе сохранять. Ссылки YouTube Music не являются прямыми аудиофайлами."
            textSize = 14f
            setPadding(0, 18, 0, 8)
        })
        layout.addView(urlInput)
        layout.addView(download)
        layout.addView(overlay)
        layout.addView(mediaAccess)
        layout.addView(start)
        setContentView(layout)
    }

    private fun downloadAuthorizedFile() {
        val raw = urlInput.text.toString().trim()
        val uri = runCatching { Uri.parse(raw) }.getOrNull()
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            Toast.makeText(this, "Введи корректную HTTP(S)-ссылку на аудиофайл", Toast.LENGTH_LONG).show()
            return
        }
        val name = (uri.lastPathSegment ?: "audio").substringAfterLast('/')
        val request = DownloadManager.Request(uri)
            .setTitle(name.ifBlank { "audio" })
            .setDescription("Загрузка аудиофайла")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(this, "Загрузка добавлена", Toast.LENGTH_SHORT).show()
    }
}

package com.example.trackfloat

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification

class TrackNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val packageName = sbn.packageName.lowercase()
        if (!packageName.contains("music") && !packageName.contains("youtube")) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val artist = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim().orEmpty()
        if (title.isNotBlank()) {
            getSharedPreferences("track", MODE_PRIVATE).edit()
                .putString("title", title)
                .putString("artist", artist)
                .apply()
        }
    }
}

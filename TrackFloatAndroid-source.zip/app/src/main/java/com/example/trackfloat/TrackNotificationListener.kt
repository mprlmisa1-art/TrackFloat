package com.example.trackfloat

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class TrackNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val artist = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isNotBlank()) {
            getSharedPreferences("track", MODE_PRIVATE).edit()
                .putString("title", title)
                .putString("artist", artist)
                .apply()
        }
    }
}
